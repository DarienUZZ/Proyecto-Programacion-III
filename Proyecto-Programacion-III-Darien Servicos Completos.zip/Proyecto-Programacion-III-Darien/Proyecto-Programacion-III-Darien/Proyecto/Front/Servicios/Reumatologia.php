<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Reumatología</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="/Proyecto/Front/Style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container">
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/Index.html">Inicio</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Acerca de Nosotros</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/PaginaServicios.html">Servicios</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacto</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacts</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Pages</a>
            </li>
          </ul>
          <ul class="navbar-nav ms-auto">
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Inicio sesión/Registro</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container mt-5">
      <section>
        <h2 class="text-center">¿Qué es la Reumatología?</h2>
        <p>
          La Reumatología es la especialidad médica que se encarga de prevenir, diagnosticar y tratar las enfermedades musculoesqueléticas y autoinmunes sistémicas. Se trata de una de las especialidades que más avances en diagnóstico y tratamiento ha experimentado en los últimos años.
        </p>
        <p>
          Existen más de 200 enfermedades reumáticas y pueden afectar a cualquier rango de edad, desde niños hasta ancianos. Son la segunda causa de consulta, tras las infecciones respiratorias agudas, en Atención Primaria y la primera causa de incapacidad en nuestro medio. Además, las enfermedades del aparato locomotor son las que más deterioran la calidad de vida de las personas, por encima de las enfermedades de pulmón y corazón.
        </p>
        <p>
          Las enfermedades musculoesqueléticas afectan a huesos, músculos y articulaciones, así como a los tejidos que los rodean, pudiendo producir dolor, inflamación, rigidez, limitación de movimiento y deformidad. Por otra parte, las enfermedades autoinmunes sistémicas, como el lupus, el síndrome de Sjögren, la esclerodermia o la dermatomiositis, pueden afectar a cualquier órgano del cuerpo, como los riñones, el pulmón, la piel, el corazón o el cerebro. Estas enfermedades suelen ser crónicas, por lo que precisan de seguimiento por el reumatólogo a lo largo de toda la vida.
        </p>
        <div class="text-center">
          <img src="imgServicios2/Reumatologia.jpg" alt="Reumatologia" class="img-fluid mt-4" style="max-width: 40%; height: auto;" />
        </div>
      </section>

      <section class="mt-5">
        <h2 class="text-center">¿Cuándo acudir al reumatólogo?</h2>
        <p>
          Al ser una consulta de atención especializada, generalmente será el médico de atención primaria quien derive al paciente. Retrasar la visita al reumatólogo puede generar lesiones irreversibles. En cambio, un tratamiento temprano puede evitar que aparezcan lesiones graves, evitando a su vez la discapacidad que estas pueden generar. Por eso es muy importante la detección precoz de estas enfermedades.
        </p>
        <p>
          El reumatólogo es el médico más capacitado para tratar las enfermedades del aparato locomotor y autoinmunes sistémicas. En la mayoría de las enfermedades reumáticas no es necesario el tratamiento quirúrgico.
        </p>
        <p>
          Generalmente, el síntoma más importante que lleva a una persona a acudir al reumatólogo es el dolor en alguna zona del aparato locomotor. Pero también pueden ser otros como hinchazón, rigidez matutina o disminución de la movilidad, por citar algunos.
        </p>
        <p>
          Si presenta inflamación de las articulaciones no causada por un golpe, sospecha que puede estar sufriendo una enfermedad reumática, o siente dolor muscular u óseo, acuda al reumatólogo lo antes posible.
        </p>
      </section>

      <div class="text-center mt-5 mb-5">
        <a href="#" class="btn btn-primary btn-lg">Reserva ya</a>
      </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>