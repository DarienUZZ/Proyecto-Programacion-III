<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pediatría</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="/Proyecto/Front/Style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container">
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/Index.html">Inicio</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Acerca de Nosotros</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/PaginaServicios.html">Servicios</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacto</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacts</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Pages</a>
            </li>
          </ul>
          <ul class="navbar-nav ms-auto">
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Inicio sesión/Registro</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container mt-5">
      <section>
        <h2 class="text-center">¿Qué es la Pediatría?</h2>
        <p>
          A la Pediatría le incumbe todo cuanto se refiere a los cuidados del niño y adolescente sano (Pediatría Preventiva), a los modos de asistencia médica integral, total y continuada en el niño y el adolescente en estado de enfermedad (Pediatría Clínica), y a cuanto atañe al niño y adolescente sano y enfermo en sus interrelaciones individuales y con la comunidad en el medio físico y humano en que de manera ininterrumpida y con características propias se desarrolla (Pediatría Social).
        </p>
        <div class="text-center">
          <img src="imgServicios2/imgbebe1.jpg" alt="Pediatria" class="img-fluid mt-4" style="max-width: 40%; height: auto;" />
        </div>
      </section>

      <section class="mt-5">
        <h2 class="text-center">¿Cuándo debo ir?</h2>
        <p>
          Los niños y las niñas tienen controles de salud con mayor frecuencia cuando son más jóvenes que cuando son adolescentes. Esto se debe a que el desarrollo es más rápido durante estos años. Cada control con el pediatra incluye un examen físico completo, donde se verifica el crecimiento y desarrollo del bebé o del niño o niña y el adolescente con el fin de encontrar o prevenir problemas. Asimismo, la valoración de estudios de la audición y la visión y otros exámenes serán parte de algunas de las consultas o controles. Incluso, si su hijo o hija está saludable, los controles con el pediatra son un buen momento para enfocarse en su bienestar integral.
        </p>
        <p>
          A veces para los padres es difícil saber si su hijo está enfermo o no. Muchas veces, no es necesario acudir de urgencia a la clínica o el hospital, y la consulta de pediatría le permite la valoración por enfermedades comunes de la infancia, que se pueden presentar como tos y secreción nasal, congestión, dolor de garganta, dolor de oídos, alergias y brotes en la piel, fiebre, vómitos, diarrea, dolor abdominal, entre otros. Una valoración apropiada por el pediatra en un ambiente seguro y cálido para su hijo o hija permitirá establecer un diagnóstico y tratamiento adecuado en el manejo de la enfermedad detectada.
        </p>
        <p>
          De igual manera, estas visitas al pediatra (de seguimiento, rutinario o por enfermedad), se deben aprovechar para consultarle al pediatra sobre las preocupaciones o problemas notados en el desarrollo, comportamiento o aprendizaje de sus hijos o hijas, ya que se pueden detectar de manera temprana algunas condiciones médicas tales como el trastorno de déficit atencional con inatención, impulsividad o hiperactividad, trastornos de conducta o trastornos del espectro autista, entre otros; en los cuales, una intervención multidisciplinaria pronta podría ayudar a buscar los enfoques que funcionan mejor para el diagnóstico de su hijo o hija, y poder colaborarle a mejorar y salir adelante, y que sea feliz en todos sus entornos, y por consiguiente sus familias y profesorado.
        </p>
      </section>

      <div class="text-center mt-5 mb-5">
        <a href="#" class="btn btn-primary btn-lg">Reserva ya</a>
      </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
