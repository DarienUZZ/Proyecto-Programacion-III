<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Identidad Mental</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="/Proyecto/Front/Style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container">
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/Index.html">Inicio</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Acerca de Nosotros</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/PaginaServicios.html">Servicios</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacto</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacts</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Pages</a>
            </li>
          </ul>
          <ul class="navbar-nav ms-auto">
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Inicio sesión/Registro</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container mt-5">
      <section>
        <h2 class="text-center">¿Qué es la Identidad Mental?</h2>
        <p>
          La identidad mental se refiere al sentido de quién eres y cómo te ves a ti mismo en términos de tus pensamientos, creencias y emociones. Es la manera en que entiendes tu propia mente y tu percepción de ti mismo. Incluye aspectos como tus valores, tus intereses, tus objetivos y tu autoconcepto.
        </p>
        <div class="text-center">
          <img src="imgServicios2/identidadmental.jpg" alt="Identidad Mental" class="img-fluid mt-4" style="max-width: 60%; height: auto;" />
        </div>
      </section>

      <section class="mt-5">
        <h2 class="text-center">¿Cómo podemos ayudar?</h2>
        <ul>
          <li><strong>Exploración del Autoconcepto:</strong> Ayuda a la persona a explorar y entender su autoconcepto, identificando creencias y percepciones sobre sí misma que pueden influir en su identidad.</li>
          <li><strong>Terapia Cognitivo-Conductual:</strong> Utiliza técnicas para identificar y modificar patrones de pensamiento negativos o distorsionados que afectan la autoimagen y el sentido de identidad.</li>
          <li><strong>Autoconocimiento:</strong> Facilita el proceso de autoconocimiento a través de la reflexión sobre experiencias pasadas, valores, intereses y metas, ayudando a la persona a construir una identidad más sólida y coherente.</li>
          <li><strong>Desarrollo de Habilidades de Afrontamiento:</strong> Enseña habilidades para manejar el estrés y las emociones, que pueden contribuir a una mejor comprensión y aceptación de uno mismo.</li>
          <li><strong>Exploración de Identidad Social:</strong> Ayuda a entender cómo las relaciones y el entorno social influyen en la identidad, trabajando para mejorar la forma en que la persona se relaciona con los demás y con su entorno.</li>
        </ul>
      </section>

      <div class="text-center mt-5 mb-5">
        <a href="#" class="btn btn-primary btn-lg">Más información</a>
      </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
