<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Urología</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="/Proyecto/Front/Style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container">
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/Index.html">Inicio</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Acerca de Nosotros</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/PaginaServicios.html">Servicios</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacto</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacts</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Pages</a>
            </li>
          </ul>
          <ul class="navbar-nav ms-auto">
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Inicio sesión/Registro</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container mt-5">
      <section>
        <h2 class="text-center">¿Qué es la Urología?</h2>
        <p>
          La Urología es la especialidad médico quirúrgica que se encarga de la prevención, diagnóstico y tratamiento de enfermedades morfológicas renales, de las del aparato urinario y retro-peritoneo que afectan a ambos sexos, así como las enfermedades del aparato genital masculino, sin diferencia de edad.
        </p>
        <p>
          Cómo ámbito anatómico de actuación, contempla el riñón y sus estructuras adyacentes, las vías urinarias y el aparato genital masculino, atendiendo las disfunciones de los siguientes órganos y estructuras:
        </p>
        <ul>
          <li>Vejiga</li>
          <li>Riñón</li>
          <li>Glándula suprarrenal</li>
          <li>Próstata</li>
          <li>Pene</li>
          <li>Escroto</li>
          <li>Testículo</li>
          <li>Epidídimo</li>
          <li>Uréter</li>
          <li>Vía seminal</li>
          <li>Uretra</li>
          <li>Estructuras del suelo pelviano</li>
        </ul>
        <p>
          La urología puede abordar, desde un punto de vista quirúrgico, médico e integral, todas las dolencias de su área de influencia nosológica (enfermedades, signos clínicos, síndrome y síntomas) y anatómica (órganos, sistemas y aparatos), pudiendo dar respuesta a nuestros pacientes del GAM, desde un conocimiento completo y profundo de la especialidad.
        </p>
        <div class="text-center">
          <img src="imgServicios2/Urologia.jpg" alt="Bebé" class="img-fluid mt-4" style="max-width: 40%; height: auto;" />
        </div>
      </section>

      <section class="mt-5">
        <h2 class="text-center">¿Cuándo acudir a urología?</h2>
        <p>
          Visitar al urólogo es algo que se debe hacer periódicamente para prevenir y asegurar el correcto funcionamiento de nuestro organismo, no obstante hay algunas enfermedades que suelen ser motivo de consulta inmediata:
        </p>
        <ul>
          <li>Sangre en la orina</li>
          <li>Presencia de cálculos (piedras) en el riñón</li>
          <li>Fimosis</li>
          <li>Incontinencia</li>
          <li>Infecciones urológicas</li>
          <li>Eyaculación precoz</li>
          <li>Disfunción eréctil</li>
        </ul>
        <p>
          En el caso de los hombres, se recomienda visitar al urólogo con más frecuencia a partir de los 45 años, pues es cuando el riesgo de padecer en enfermedades propias de la próstata como lo es el cáncer o el crecimiento prostático.
        </p>
        <p>
          Este especialista puede ayudarte también a disipar cualquier duda que surja sobre sexualidad o el funcionamiento del sistema urinario, no importa la edad que tengas; el conocimiento es crucial para la prevención y asegurar una vida sana.
        </p>
        <p>
          Si percibes anomalías en el funcionamiento de tu sistema urinario o genital, no dudes en acudir con un experto, evita la posibilidad de que los síntomas se compliquen.
        </p>
      </section>

      <div class="text-center mt-5 mb-5">
        <a href="#" class="btn btn-primary btn-lg">Reserva ya</a>
      </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>