<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Endocrinología</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="/Proyecto/Front/Style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container">
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/Index.html">Inicio</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Acerca de Nosotros</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/PaginaServicios.html">Servicios</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacto</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacts</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Pages</a>
            </li>
          </ul>
          <ul class="navbar-nav ms-auto">
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Inicio sesión/Registro</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container mt-5">
      <section>
        <h2 class="text-center">¿Qué es la Endocrinología?</h2>
        <p>
          La endocrinología es la rama de la medicina que se especializa en el diagnóstico y tratamiento de trastornos del sistema endocrino, que incluye las glándulas y órganos que elaboran hormonas. Estos trastornos incluyen diabetes, infertilidad, y problemas tiroideos, suprarrenales y de la hipófisis.
        </p>
        <p>
          Nuestro equipo de endocrinos de alto nivel evalúa la relación entre la nutrición y las enfermedades de las personas para mejorar y mantener su salud, y están equipados para tratar diversas disfunciones y trastornos endocrinos. Trabajan en estrecha colaboración con otros especialistas a fin de proporcionar un enfoque multidisciplinario para los problemas médicos de las personas.
        </p>
        <p>
          El sistema endocrino del cuerpo comprende el páncreas, la tiroides, la glándula paratiroidea, la glándula pineal, el hipotálamo, la hipófisis y las glándulas suprarrenales, además de los ovarios y los testículos. También abarca muchos otros órganos que responden a las hormonas, que las modifican o que las metabolizan.
        </p>
        <div class="text-center">
          <img src="imgServicios2/Endocrinologia.jpg" alt="Endocrinología" class="img-fluid mt-4" style="max-width: 40%; height: auto;" />
        </div>
      </section>

      <section class="mt-5">
        <h2 class="text-center">¿Qué padecimientos se tratan con frecuencia?</h2>
        <ul>
          <li>Diabetes</li>
          <li>Obesidad y trastornos de la alimentación</li>
          <li>Lípidos (colesterol y triglicéridos elevados)</li>
          <li>Enfermedades en la glándula tiroides</li>
          <li>Enfermedades del metabolismo mineral (osteoporosis)</li>
          <li>Esteatosis hepática no alcohólica (hígado graso)</li>
        </ul>
        <p>
          Sin embargo, también atendemos padecimientos del hipotálamo, hipófisis, glándulas paratiroides, páncreas, glándulas suprarrenales, ovarios, testículos, entre otras.
        </p>
      </section>

      <div class="text-center mt-5 mb-5">
        <a href="#" class="btn btn-primary btn-lg">Reserva ya</a>
      </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
