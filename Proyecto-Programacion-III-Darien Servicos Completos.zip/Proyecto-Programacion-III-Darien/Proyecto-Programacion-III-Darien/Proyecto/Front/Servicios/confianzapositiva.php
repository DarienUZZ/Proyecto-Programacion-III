<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Confianza Positiva</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="/Proyecto/Front/Style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container">
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/Index.html">Inicio</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Acerca de Nosotros</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/PaginaServicios.html">Servicios</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacto</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacts</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Pages</a>
            </li>
          </ul>
          <ul class="navbar-nav ms-auto">
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Inicio sesión/Registro</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container mt-5">
      <section>
        <h2 class="text-center">¿Qué es la Confianza Positiva?</h2>
        <p>
          La confianza positiva tiene como base la psicología Adleriana, la cual lleva ya bastantes años utilizándose en la crianza con muy buenos resultados. La filosofía de la disciplina positiva se basa en el respeto mutuo (adultos y niños), amabilidad y firmeza, enfocándose en desarrollar en los niños habilidades de vida que les favorezca su futuro.
        </p>
        <div class="text-center">
          <img src="imgServicios2/confianzapositiva.jpg" alt="Disciplina Positiva" class="img-fluid mt-4" style="max-width: 60%; height: auto;" />
        </div>
      </section>

      <section class="mt-5">
        <h2 class="text-center">Talleres</h2>
        <p>
          Su metodología es enteramente vivencial, los participantes viven al máximo durante cada sesión y en el transcurso de la semana, todo lo aprendido. Se abordan los distintos estilos de crianza, se profundizará en las herramientas con las que cuenta la disciplina positiva, se enseñará a ser amable y firme a la vez y se trabajará semana a semana en grupo la retroalimentación de lo que se ha practicado en casa. Además, se brindarán soluciones respetuosas para evitar el castigo físico y se explorarán las repercusiones del mismo.
        </p>
      </section>

      <section class="mt-5">
        <h2 class="text-center">Terapia</h2>
        <p>
          Brindamos un servicio integral y personalizado para familias que buscan mejorar su interacción familiar, buscar herramientas para manejar las emociones de los niños que a la vez enseñen valores para fortalezcan su autoestima e inteligencia emocional.
        </p>
      </section>

      <div class="text-center mt-5 mb-5">
        <a href="#" class="btn btn-primary btn-lg">Más información</a>
      </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
