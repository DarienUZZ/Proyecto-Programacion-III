<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Psiquiatría</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="/Proyecto/Front/Style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container">
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/Index.html">Inicio</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Acerca de Nosotros</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="/Proyecto/Front/PaginaServicios.html">Servicios</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacto</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Contacts</a>
            </li>
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Pages</a>
            </li>
          </ul>
          <ul class="navbar-nav ms-auto">
            <li class="nav-item mx-4">
              <a class="nav-link" href="#">Inicio sesión/Registro</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container mt-5">
      <section>
        <h2 class="text-center">¿Qué es la Psiquiatría?</h2>
        <p>
          Es una especialidad médica que se dedica a la prevención, diagnóstico y al tratamiento de los trastornos del estado de ánimo (depresión y trastorno bipolar), de la ansiedad (ataques de pánico y trastorno de ansiedad generalizada), del pensamiento (esquizofrenia y otras psicosis), de las habilidades cognitivas (demencias), trastornos de la alimentación, trastornos por uso y abuso de licor y drogas. Algunos ejemplos de las enfermedades abordadas son: depresión, trastorno bipolar, ataques de pánico y esquizofrenia, abarcando poblaciones que van desde la infancia hasta el adulto mayor.
        </p>
        <div class="text-center">
          <img src="imgServicios2/imgPsiquiatra.jpg" alt="Psiquiatra" class="img-fluid mt-4" style="max-width: 40%; height: auto;" />
        </div>
      </section>

      <section class="mt-5">
        <h2 class="text-center">¿Cuándo debo ir al Psiquiatra?</h2>
        <p>
          <strong>Ir al psiquiatra cuando se tengan cambios en la vida cotidiana:</strong>
        </p>
        <p>
          Las alteraciones en la vida cotidiana son síntomas que en un primer momento se puede pensar que se deben a otras patologías que no sean mentales, pero realmente sí tienen una relación. Los principales síntomas son:
        </p>
        <ul>
          <li>Cambios en los hábitos alimenticios: adelgazamiento, dieta excesiva, ingesta de comida excesiva, etc.</li>
          <li>Cambios en los hábitos de descanso: exceso o falta de sueño, despertar por la noche, tardar mucho en conciliar el sueño, cansancio sin motivo, etc.</li>
          <li>Falta de concentración</li>
          <li>Problemas de memoria</li>
        </ul>
        <p>
          <strong>Ir al psiquiatra cuando se tengan cambios en el estado de ánimo:</strong>
        </p>
        <p>
          Los cambios en el estado de ánimo, en la personalidad o en el comportamiento, es más fácil que lo vean los familiares y amigos del paciente que él mismo.
        </p>
        <ul>
          <li>Dificultad para superar problemas o tomar decisiones</li>
          <li>Ansiedad o exceso de preocupación anormal por alguno o varios temas</li>
          <li>Pensamiento acelerado o enlentecido</li>
          <li>Cambios de ánimo muy extremos</li>
          <li>Ira y/o susceptibilidad con los amigos, familiares o la pareja</li>
          <li>Indiferencia hacia el futuro: falta de ilusiones y de proyecto de vida</li>
          <li>Incapacidad para ilusionarse ni disfrutar con nada</li>
          <li>Ideas extrañas</li>
        </ul>
        <p>
          <strong>Ir al psiquiatra cuando se tengan ideas extrañas:</strong>
        </p>
        <p>
          Los pensamientos extraños, como manías y miedos excesivos o alucinaciones, son signos muy frecuentes en enfermedades mentales. Las más destacadas son:
        </p>
        <ul>
          <li>Pensamiento paranoide: pensar que todos actúan contra la persona</li>
          <li>Obsesiones desmesuradas: lavarse las manos compulsivamente, hacer colecciones absurdas, comprobar una y otra vez las cosas, exceso de perfeccionismo y meticulosidad, etc.</li>
          <li>Alucinaciones: sensación de haber oído o visto algo sin que los demás se den cuenta, como sombras, figuras extrañas, voces, apariciones misteriosas, etc.</li>
          <li>Miedo excesivo: a salas de cine, campos de fútbol, ascensores, autobuses, conciertos, fiestas, que provoca sensación de asfixia, taquicardias, mareos, vómitos o incluso desmayos.</li>
        </ul>
      </section>

      <div class="text-center mt-5 mb-5">
        <a href="#" class="btn btn-primary btn-lg">Reserva ya</a>
      </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>